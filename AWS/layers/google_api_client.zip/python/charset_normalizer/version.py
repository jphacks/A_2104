"""
Expose version
"""

__version__ = "2.0.7"
VERSION = __version__.split(".")
